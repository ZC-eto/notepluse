const fs = require('node:fs')
const path = require('node:path')
const os = require('node:os')

const CONFIG_NAME = 'md-workspace-config.json'
const DEFAULT_FOLDER_NAME = 'ZToolsNotes'

function safeGetPath(name) {
  try {
    if (window.ztools && typeof window.ztools.getPath === 'function') {
      return window.ztools.getPath(name)
    }
  } catch (e) {
    console.warn('[md-workspace] getPath failed', name, e)
  }
  return null
}

function getConfigPath() {
  const userData = safeGetPath('userData')
  if (userData) return path.join(userData, CONFIG_NAME)
  return path.join(os.homedir(), '.md-workspace-config.json')
}

function readConfig() {
  const configPath = getConfigPath()
  try {
    if (fs.existsSync(configPath)) {
      return JSON.parse(fs.readFileSync(configPath, 'utf8'))
    }
  } catch (e) {
    console.error('[md-workspace] readConfig failed', e)
  }
  return {}
}

function writeConfig(partial) {
  const configPath = getConfigPath()
  const next = { ...readConfig(), ...partial }
  fs.mkdirSync(path.dirname(configPath), { recursive: true })
  fs.writeFileSync(configPath, JSON.stringify(next, null, 2), 'utf8')
  return next
}

function sanitizeTitle(title) {
  return (
    String(title || '未命名笔记')
      .replace(/[\\/:*?"<>|]/g, '_')
      .replace(/\s+/g, ' ')
      .trim() || '未命名笔记'
  )
}

function ensureSampleNote(root) {
  const sample = path.join(root, '本周计划.md')
  if (fs.existsSync(sample)) return sample

  const content = `# 本周计划

## 进行中

- [ ] 写产品需求 @start(2026-07-20) @end(2026-07-24) #产品
- [ ] 设计交互稿 @start(2026-07-24) @end(2026-07-28) #设计
- [x] 完成技术调研 @start(2026-07-15) @end(2026-07-18) #研发

## 备忘

会议纪要和灵感可以写在这里。
`

  fs.writeFileSync(sample, content, 'utf8')
  return sample
}

function getNotesRoot() {
  const cfg = readConfig()
  if (cfg.notesRoot && fs.existsSync(cfg.notesRoot)) return cfg.notesRoot

  const documents = safeGetPath('documents') || path.join(os.homedir(), 'Documents')
  const root = path.join(documents, DEFAULT_FOLDER_NAME)
  const isNew = !fs.existsSync(root)
  fs.mkdirSync(root, { recursive: true })
  writeConfig({ notesRoot: root })
  // 仅在首次创建默认目录时写入示例笔记，避免用户删空后被反复生成
  if (isNew) ensureSampleNote(root)
  return root
}

function listNotes() {
  const root = getNotesRoot()
  const files = fs
    .readdirSync(root)
    .filter((name) => /\.(md|markdown)$/i.test(name))
    .map((name) => {
      const fullPath = path.join(root, name)
      const stat = fs.statSync(fullPath)
      return {
        name,
        path: fullPath,
        mtime: stat.mtimeMs,
        size: stat.size,
      }
    })
    .sort((a, b) => b.mtime - a.mtime)
  return { root, files }
}

function readNote(filePath) {
  return fs.readFileSync(filePath, 'utf8')
}

function writeNote(filePath, content) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true })
  fs.writeFileSync(filePath, content, 'utf8')
  return true
}

function createNote(title) {
  const root = getNotesRoot()
  const safe = sanitizeTitle(title)
  let filePath = path.join(root, safe + '.md')
  let i = 1
  while (fs.existsSync(filePath)) {
    filePath = path.join(root, `${safe}-${i}.md`)
    i += 1
  }
  const content = `# ${safe}\n\n`
  fs.writeFileSync(filePath, content, 'utf8')
  return { path: filePath, name: path.basename(filePath), content }
}

function deleteNote(filePath) {
  if (fs.existsSync(filePath)) fs.unlinkSync(filePath)
  return true
}

function renameNote(filePath, newTitle) {
  if (!filePath || !fs.existsSync(filePath)) {
    throw new Error('笔记不存在: ' + filePath)
  }
  const dir = path.dirname(filePath)
  const ext = path.extname(filePath) || '.md'
  const safe = sanitizeTitle(newTitle)
  let nextPath = path.join(dir, safe + ext)
  if (path.resolve(nextPath) === path.resolve(filePath)) {
    return { path: filePath, name: path.basename(filePath) }
  }
  let i = 1
  while (fs.existsSync(nextPath)) {
    nextPath = path.join(dir, `${safe}-${i}${ext}`)
    i += 1
  }
  fs.renameSync(filePath, nextPath)
  return { path: nextPath, name: path.basename(nextPath) }
}

function setNotesRoot(dirPath) {
  if (!dirPath) throw new Error('目录路径为空')
  fs.mkdirSync(dirPath, { recursive: true })
  if (!fs.existsSync(dirPath)) {
    throw new Error('目录不存在: ' + dirPath)
  }
  writeConfig({ notesRoot: dirPath })
  return dirPath
}

function getNotesRootPath() {
  return getNotesRoot()
}

function openInFolder(filePath) {
  try {
    let target = filePath
    if (!target || !fs.existsSync(target)) {
      target = getNotesRoot()
    }
    if (window.ztools && typeof window.ztools.shellShowItemInFolder === 'function') {
      window.ztools.shellShowItemInFolder(target)
      return true
    }
    if (window.ztools && typeof window.ztools.shellOpenPath === 'function') {
      const stat = fs.statSync(target)
      window.ztools.shellOpenPath(stat.isDirectory() ? target : path.dirname(target))
      return true
    }
  } catch (e) {
    console.warn('[md-workspace] openInFolder failed', e)
  }
  return false
}

function chooseNotesRoot() {
  try {
    if (window.ztools && typeof window.ztools.showOpenDialog === 'function') {
      const result = window.ztools.showOpenDialog({
        title: '选择笔记目录',
        defaultPath: getNotesRoot(),
        properties: ['openDirectory', 'createDirectory'],
      })
      if (Array.isArray(result) && result[0]) {
        return setNotesRoot(result[0])
      }
      return null
    }
  } catch (e) {
    console.warn('[md-workspace] chooseNotesRoot failed', e)
  }
  return null
}

window.services = {
  listNotes,
  readNote,
  writeNote,
  createNote,
  deleteNote,
  renameNote,
  setNotesRoot,
  getNotesRootPath,
  openInFolder,
  chooseNotesRoot,
  readConfig,
  writeConfig,
}
